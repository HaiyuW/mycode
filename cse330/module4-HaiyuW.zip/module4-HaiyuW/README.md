# CSE330
Haiyu Wang, 475533

## 1. Regular Expression
* regex1.txt
* regex2.txt
* regex3.txt

## 2. Baseball Stats Counter
* baseball.py
* Usage: python3 baseball.py [filename]
