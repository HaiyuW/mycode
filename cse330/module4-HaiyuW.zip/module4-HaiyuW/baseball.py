import re
import sys

# get filename from arguments
if len(sys.argv)!=2:
    print('Usage: baseball.py [filename]')
    exit()

file = str(sys.argv[1])
# regular expression
regex = re.compile(r"(\w*\s\w*)\sbatted\s(\d)\stimes\swith\s(\d)\shits\sand\s(\d(?=\sruns))")

# form nameSet, using set to remove duplicate name
nameSet = set()
with open(file) as f:
    for line in f:
        match = regex.match(line)
        if match is not None:
            nameSet.add(match.group(1))

# create result dictionary to store name, bats, hits
result = dict()
for name in nameSet:
    result[name] = [0,0]

with open(file) as f:
    for line in f:
        match = regex.match(line)
        if match is not None:
            name = match.group(1)
            bats = match.group(2)
            hits = match.group(3)
            result[name][0] += int(bats)
            result[name][1] += int(hits)

# create res dictionary to get batting avg
res = dict()
for name in nameSet:
    res[name] = float(result[name][1])/float(result[name][0])

# sort dictionary by values and print
resList = sorted(res.items(), key=lambda x: x[1], reverse=True)

for res in resList:
    print(res[0]+": %.3f" % res[1])












