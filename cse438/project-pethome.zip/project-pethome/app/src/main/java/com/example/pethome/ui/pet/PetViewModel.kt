package com.example.pethome.ui.pet

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pethome.Data.Animal
import com.example.pethome.Data.Token
import com.example.pethome.Network.DogPet.DogPetRepository

class PetViewModel : ViewModel() {
    public var token: MutableLiveData<Token> = MutableLiveData()
    public var dogPetRepository: DogPetRepository = DogPetRepository()
    public var animal: MutableLiveData<Animal> = MutableLiveData()

    fun getToken() {
        dogPetRepository.getToken(token)
    }

    fun getTypeDog(param: String) {
        dogPetRepository.getTypeDog(animal, param)
    }

}