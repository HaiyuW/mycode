package com.example.pethome.Data

data class User(
    val username: String,
    val email: String,
    val uid: String
)