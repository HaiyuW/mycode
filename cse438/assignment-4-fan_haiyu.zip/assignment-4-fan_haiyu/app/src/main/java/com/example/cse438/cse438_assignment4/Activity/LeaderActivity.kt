package com.example.cse438.cse438_assignment4.Activity

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cse438.cse438_assignment4.Adapter.LeaderAdapter
import com.example.cse438.cse438_assignment4.Data.User
import com.example.cse438.cse438_assignment4.R
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.Query
import kotlinx.android.synthetic.main.activity_leader.*

// show leader board including username, chips
class LeaderActivity : AppCompatActivity() {
    lateinit var cancelButton: Button
    lateinit var userDB: FirebaseFirestore
    private var userlist: ArrayList<User> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leader)

        cancelButton = cancelBtn

        userDB = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setTimestampsInSnapshotsEnabled(true)
            .build()
        userDB.firestoreSettings = settings

        val recyclerView = leader_recycler_view
        val adapter = LeaderAdapter(userlist)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // order by the chips number
        userDB.collection("accounts")
            .orderBy("chips", Query.Direction.DESCENDING)
            .get()
            .addOnCompleteListener { task ->

                if (task.isSuccessful) {
                    userlist.clear()
                    for (document in task.result!!) {
                        userlist.add(
                            User(
                                document.get("username").toString(),
                                document.get("email").toString(),
                                document.get("uid").toString(),
                                document.get("wins").toString().toInt(),
                                document.get("loses").toString().toInt(),
                                document.get("chips").toString().toInt()
                            )
                        )
                    }
                    adapter.notifyDataSetChanged()
                } else {
                    Log.e("Error", "fail to get data")
                }
            }


    }

    override fun onStart() {
        super.onStart()

        cancelButton.setOnClickListener{
            finish()
        }
    }
}