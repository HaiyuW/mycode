package com.example.cse438.cse438_assignment4.Data

data class History(
    val uid: String,
    val status: String,
    val chipStatus: String,
    val time: String
)