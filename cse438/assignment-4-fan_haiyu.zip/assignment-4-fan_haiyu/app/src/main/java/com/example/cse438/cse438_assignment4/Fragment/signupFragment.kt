package com.example.cse438.cse438_assignment4.Fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.cse438.cse438_assignment4.Activity.GameActivity
import com.example.cse438.cse438_assignment4.Data.User
import com.example.cse438.cse438_assignment4.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import kotlinx.android.synthetic.main.fragment_register.*

class SignUpFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var userDB: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()

        userDB = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setTimestampsInSnapshotsEnabled(true)
            .build()
        userDB.firestoreSettings = settings

        signupBtn.setOnClickListener {
            val username = inputUser.text.toString()
            val email = emailAdrReg.text.toString()
            val password = passwordReg.text.toString()
            val wins: Int = 0
            val loses: Int = 0
            val chips: Int = 1000

            if (username!=""&&email!=""&&password!="") {
                createAccount(username,email,password, wins, loses, chips)
            } else {
                Toast.makeText(this.context, "Invalid Value", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // create account using firebase authentication and insert the data into database
    private fun createAccount(username: String, email: String, password: String, wins: Int, loses: Int, chips: Int) {

        auth.createUserWithEmailAndPassword(email,password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("success", "createUserSuccess")
                    val user = auth.currentUser
                    if (user != null) {
                        addAccount(username, email, user.uid, wins, loses, chips)
                    }
                    updateUI(user)
                } else {
                    Toast.makeText(this.context, "Authentication failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun addAccount(username: String, email: String, uid: String, wins: Int, loses: Int, chips: Int) {
        val account = User(username,email,uid, wins, loses, chips)

        val accountMap: MutableMap<String, Any> = HashMap()

        accountMap["username"] = account.username
        accountMap["email"] = account.email
        accountMap["uid"] = account.uid
        accountMap["wins"] = account.wins
        accountMap["loses"] = account.loses
        accountMap["chips"] = account.chips

        userDB.collection("accounts").document(account.uid)
            .set(accountMap)
            .addOnSuccessListener { doucument ->
                Toast.makeText(this.context, "Account Created", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e->
                Toast.makeText(this.context,"Fail to Create Account", Toast.LENGTH_SHORT).show()
            }
    }


    private fun updateUI(user: FirebaseUser?) {

        var username = ""

        if (user!=null) {
            userDB.collection("accounts")
                .whereEqualTo("uid",user.uid)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        for (document in task.result!!) {
                            username = document.get("username").toString()
                        }
                        var bundle = Bundle()
                        bundle.putString("username", username)
                        bundle.putString("uid", user.uid)
                        val intent = Intent(this.context, GameActivity::class.java)
                        intent.putExtras(bundle)
                        startActivity(intent)
                        Log.e("user",username)
                    } else {
                        Log.e("d", "fail")
                    }
                }
        }
    }
}