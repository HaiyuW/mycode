package com.example.cse438.cse438_assignment4.Activity

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cse438.cse438_assignment4.Adapter.HistoryAdapter
import com.example.cse438.cse438_assignment4.Data.History
import com.example.cse438.cse438_assignment4.Data.User
import com.example.cse438.cse438_assignment4.R
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.Query
import kotlinx.android.synthetic.main.activity_history.*

// show history, including win/lose/tie and the chip status
class HistoryActivity : AppCompatActivity() {

    private lateinit var uid: String
    lateinit var userDB: FirebaseFirestore
    private var hislist: ArrayList<History> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val bundle = intent.extras
        if (bundle != null) {
            uid = bundle.getString("uid").toString()
        }

        userDB = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setTimestampsInSnapshotsEnabled(true)
            .build()
        userDB.firestoreSettings = settings

        val recyclerView = history_recycler_view
        val adapter = HistoryAdapter(hislist)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        userDB.collection("history")
            .whereEqualTo("uid", uid)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    hislist.clear()
                    for (document in task.result!!) {
                        hislist.add(
                            History(
                                document.get("uid").toString(),
                                document.get("status").toString(),
                                document.get("chipStatus").toString(),
                                document.get("time").toString()
                            )
                        )
                    }
                    adapter.notifyDataSetChanged()
                } else {
                    Log.e("Error", "fail to get data")
                }
            }

        backBtn.setOnClickListener {
            finish()
        }
    }


}