package com.example.cse438.cse438_assignment4.Data

data class User(
    val username: String,
    val email: String,
    val uid: String,
    val wins: Int,
    val loses: Int,
    val chips: Int
)