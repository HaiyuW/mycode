package com.example.cse438.cse438_assignment4.Activity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.cse438.cse438_assignment4.R
import com.example.cse438.cse438_assignment4.util.CardRandomizer
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import kotlinx.android.synthetic.main.activity_game.*
import kotlinx.android.synthetic.main.activity_leader.*
import java.util.*
import kotlin.collections.ArrayList
import android.widget.RelativeLayout
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.view.*
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GestureDetectorCompat
import com.example.cse438.cse438_assignment4.Data.User
import kotlinx.android.synthetic.main.dialog_result.*
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.os.Handler
import com.example.cse438.cse438_assignment4.Data.History
import io.grpc.internal.LogExceptionRunnable
import kotlinx.android.synthetic.main.dialog_double.*
import java.lang.Thread.sleep
import java.sql.Date
import java.time.Instant
import java.time.format.DateTimeFormatter

// Game activity to deal with main game interface
class GameActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var userDB: FirebaseFirestore
    private lateinit var uid : String
    private lateinit var userCards: LinearLayout
    private lateinit var userCards2: LinearLayout
    private lateinit var computerCards: LinearLayout
    private lateinit var computerCards2: LinearLayout
    private lateinit var gestureDetector: GestureDetectorCompat
    private lateinit var deckView: View


    private var winNum : Int = 0
    private var loseNum : Int = 0
    private var chipNum: Int = 0
    private var betAmount: Int = 0

    private var computerVal : Int = 0
    private var userVal : Int = 0

    private var firstPCCardId : Int = 0
    private var pcAceNum: Int = 0
    private var userAceNum: Int = 0

    private var height: Int = 0
    private var width: Int = 0

    private var userX: Float = 0f
    private var userY: Float = 1092f

    private var pcX: Float = 0f
    private var pcY: Float = 221f

    private val cardWidth: Float = 162f
    private val cardHeight: Float = 221f

    private val handler: Handler = Handler()

    private val picHandle: Handler = Handler()

    private var userCardNums: Int = 0
    private var pcCardNums: Int = 0

    private var isGameOver: Boolean = false
    private var isWin: Int = -1



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        // initialize the variables
        val intent = intent
        val bundle = intent.extras
        val username = bundle?.get("username").toString()
        uid = bundle?.get("uid").toString()

        deckView = cardDeck


        userDB = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setTimestampsInSnapshotsEnabled(true)
            .build()
        userDB.firestoreSettings = settings

        playerName.text = "Player Name: " + username


        auth = FirebaseAuth.getInstance()

        userCards = userCard
        userCards2 = userCard2
        computerCards = computerCard
        computerCards2 = computerCard2

        gestureDetector = GestureDetectorCompat(this, MyGestureListener())

        val metrics = this.resources.displayMetrics
        this.height = metrics.heightPixels
        this.width = metrics.widthPixels


    }

    override fun onStart() {
        super.onStart()

        val logout = logoutBtn
        val placeBet = placeBtn
        val leaderBoard = leaderBtn
        val hisBtn  = historyBtn

        userCardNums = 2
        pcCardNums = 2
        isGameOver = false
        isWin = -1

        historyBtn.visibility = ViewGroup.VISIBLE
        editBet.visibility = View.VISIBLE
        placeBet.visibility = View.VISIBLE

        // set the place bet button.
        placeBet.setOnClickListener {
            val betText = editBet.text.toString()

            if (betText == "") {
                Toast.makeText(this, "Please Enter Bet", Toast.LENGTH_SHORT).show()
            } else if (betText.toInt()<0) {
                Toast.makeText(this, "Invalid Bet", Toast.LENGTH_SHORT).show()
            } else if (betText.toInt()>chipNum) {
                Toast.makeText(this, "Bet Amount Can't Surpass Remaining Chips", Toast.LENGTH_SHORT).show()
            } else {
                editBet.visibility = ViewGroup.INVISIBLE
                placeBet.visibility = ViewGroup.INVISIBLE
                betAmount = betText.toInt()
            }
        }

        // set the logout button
        logout.setOnClickListener {
            auth.signOut()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

        // set leader board button
        leaderBoard.setOnClickListener{
            val intent = Intent(this, LeaderActivity::class.java)
            startActivity(intent)
        }

        // set history button
        hisBtn.setOnClickListener {
            val bundle = Bundle()
            bundle.putString("uid", uid)
            val intent = Intent(this, HistoryActivity::class.java)
            intent.putExtras(bundle)
            startActivity(intent)
        }


        // get the data from firebase database to show the number of wins, loses and chips
        userDB.collection("accounts")
            .whereEqualTo("uid", uid)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    var wins: String = ""
                    var loses: String = ""
                    var chips: String = ""
                    for (document in task.result!!) {
                        wins = document.get("wins").toString()
                        loses = document.get("loses").toString()
                        chips = document.get("chips").toString()
                    }

                    if (wins == "" || loses == "" || chips == ""){
                        Toast.makeText(this, "Please Logout", Toast.LENGTH_SHORT).show()
                    } else {
                        winNum = wins.toInt()
                        loseNum = loses.toInt()
                        chipNum = chips.toInt()
                        winTimes.text = "Wins: " + wins
                        loseTimes.text = "Loses: " + loses
                        chipsNum.text = "Chips: " + chips
                    }
                } else {
                    Log.e("fail", "fail to get data")
                }
            }

        Log.e("chipNum", chipNum.toString())

        // set the first 2 cards of computer and user and deal with the value
        computerVal = 0
        userVal = 0

        firstPCCardId = generateCard()

        // the position is calculated by the width and height of cards
        var newDeckView = generateBack()
        moveTo(newDeckView,0f, 221f)

        Log.e("transDP", firstPCCard.width.toString())
        Log.e("height",firstPCCard.height.toString())

        // for animation
        newDeckView = generateBack()
        moveTo(newDeckView,162f,221f)

        newDeckView = generateBack()
        moveTo(newDeckView, 0f, 1092f)

        newDeckView = generateBack()
        moveTo(newDeckView, 162f, 1092f)

        userX = 324f
        pcX = 324f

        val firstPCCardName = resources.getResourceEntryName(firstPCCardId)

        dealCardName(firstPCCardName, false)

        val secondPCCardId = generateCard()
        val secondPCCardName = resources.getResourceEntryName(secondPCCardId)

        dealCardName(secondPCCardName, false)


        val firstUserCardId = generateCard()
        val firstUserCardName = resources.getResourceEntryName(firstUserCardId)
        dealCardName(firstUserCardName, true)

        val secondUserCardId = generateCard()
        val secondUserCardName = resources.getResourceEntryName(secondUserCardId)
        dealCardName(secondUserCardName, true)

        // use handler to implement delay
        val r: Runnable = Runnable {
            secondPCCard.setImageResource(secondPCCardId)
            firstUserCard.setImageResource(firstUserCardId)
            secondUserCard.setImageResource(secondUserCardId)
        }

        picHandle.postDelayed(r,1000)
    }


    override fun onTouchEvent(event: MotionEvent?): Boolean {
        gestureDetector.onTouchEvent(event)

        return super.onTouchEvent(event)
    }

    // transform the card name into number and deal with ace
    private fun dealCardName(name: String, isUser: Boolean) {
        val list = name.split("_")
        if (isUser) {
            if (list.size > 1) {
                if (list[1].equals("ace")){
                    userAceNum ++
                    userVal+=11
                    if (userVal>21){
                        userVal = userVal-11+1
                    }
                } else {
                    userVal += 10
                }
            } else {
                userVal += parseCard(name)
            }

        } else {
            if (list.size > 1) {
                if (list[1].equals("ace")) {
                    pcAceNum++
                    computerVal+=11
                    if (computerVal>21){
                        computerVal = computerVal-11+1
                    }
                } else {
                    computerVal += 10
                }
            } else {
                computerVal += parseCard(name)
            }
        }
    }

    // judge the final result of the game
    private fun judge() {

        // userVal<0 -> user bust
        if (userVal < 0) {
            loseNum ++
            chipNum -= betAmount
            isWin = -1
            updateCollection()
            val msg: String = "Lose: You Bust!"
            dialogView(msg)
            return
        }

        // computerVal == 21 -> dealer wins
        if (computerVal == 21) {
            loseNum ++
            chipNum -= betAmount
            isWin = -1
            updateCollection()
            val msg: String = "Lose: Dealer Has 21!"
            dialogView(msg)
            return
        }

        // computerVal is larger -> dealer wins
        if (computerVal > userVal) {
            loseNum ++
            chipNum -= betAmount
            isWin = -1
            updateCollection()
            val msg: String = "Lose: Dealer is Larger!"
            dialogView(msg)
            return
        }

        // computerVal is smaller -> user wins
        if (computerVal < userVal) {
            winNum ++
            chipNum += betAmount
            isWin = 1
            updateCollection()
            val msg: String = "Win: Congratulation"
            dialogView(msg)
            return
        }

        // computerVal == userVal -> tie
        if (computerVal == userVal) {
            val msg: String = "You have a tie"
            isWin = 0
            updateCollection()
            dialogView(msg)
            return
        }

    }

    // show a dialog containing the msg
    private fun dialogView(msg: String) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_result, null)
        val mBuilder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setTitle(msg)

        val mAlertDialog = mBuilder.show()

        mAlertDialog.confResult.setOnClickListener{
            mAlertDialog.dismiss()
            finish()
            overridePendingTransition(0, 0)
            startActivity(getIntent())
            overridePendingTransition(0, 0)
        }
    }

    // update the data in the firebase database
    private fun updateCollection() {
        val userInfo = userDB.collection("accounts").document(uid)
        userInfo.update("wins", winNum)
        userInfo.update("loses", loseNum)
        userInfo.update("chips", chipNum)

        var status: String = ""
        var chipStatus: String = ""
        if (isWin == -1){
            status = "Lose"
            chipStatus = "-$betAmount"
        } else if (isWin == 0) {
            status = "Tie"
            chipStatus = "0"
        } else if (isWin == 1) {
            status = "Win"
            chipStatus = "+$betAmount"
        }

        val history = History(uid, status, chipStatus, Date().toString())

        val historyMap: MutableMap<String, Any> = HashMap()

        historyMap["uid"] = history.uid
        historyMap["status"] = history.status
        historyMap["chipStatus"] = history.chipStatus
        historyMap["time"] = history.time

        userDB.collection("history")
            .add(historyMap)
            .addOnSuccessListener { doucument ->
                Log.d("history", "Insert Success")
            }
            .addOnFailureListener { e->
                Log.d("history", "Insert Fail")
            }

        Log.e("chipupdate", chipNum.toString())
    }

    // computer actions when user ends
    private fun computerTurn() {
        if (userVal < 0) {

        } else {

            while (computerVal < 17) {
                val newCardId = generateCard()
                val newCardName = resources.getResourceEntryName(newCardId)
                dealCardName(newCardName, false)
                createImage(computerCards, newCardId)
            }

            if (computerVal > 21) {
                Toast.makeText(this, "Dealer Bust", Toast.LENGTH_SHORT).show()
                computerVal = -1
            }
        }

        isGameOver = true

        firstPCCard.setImageResource(firstPCCardId)
        judge()
    }

    // parse card from name
    private fun parseCard(name: String) : Int {
        var res = name.replace("[^0-9]".toRegex(), "")
        return res.toInt()
    }

    // animation from card deck to certain position
    fun moveTo(deckView: View, targetX: Float, targetY: Float) {
        val animSetXY = AnimatorSet()

        val location = IntArray(2)
        deckView.getLocationInWindow(location)

        Log.e("deck x", location[0].toString())
        Log.e("deck y", location[1].toString())

        val x = ObjectAnimator.ofFloat(
            deckView,
            "translationX",
            location[0].toFloat(),
            targetX
        )

        val y = ObjectAnimator.ofFloat(
            deckView,
            "translationY",
            location[1].toFloat(),
            targetY
        )

        animSetXY.playTogether(x,y)
        animSetXY.duration = 1000
        animSetXY.start()

        // use handler for delay
        val runnable: Runnable = Runnable {
            deckView.visibility = ViewGroup.GONE
        }
        handler.postDelayed(runnable,1000)
    }

    // gesture listener
    private inner class MyGestureListener: GestureDetector.SimpleOnGestureListener() {

        private var swipeDistance = 150


        // When double tap, user get another card
        override fun onDoubleTap(e: MotionEvent?): Boolean {
            // if user don't place bet, card shouldn't be deliver
            if (editBet.visibility != ViewGroup.INVISIBLE) {
                Toast.makeText(this@GameActivity, "Please Enter Bet", Toast.LENGTH_SHORT).show()
                return false
                // if game is over, card shouldn't be deliver
            } else if (isGameOver){
                Toast.makeText(this@GameActivity, "Game Is Over", Toast.LENGTH_SHORT).show()
                return false
            } else {
                val id = generateCard()
                val name = resources.getResourceEntryName(id)
                dealCardName(name, true)

                createImage(userCards, id)

                if (userVal > 21) {
                    Toast.makeText(this@GameActivity, "You Bust", Toast.LENGTH_SHORT).show()
                    userVal = -1
                    computerTurn()
                }
                return true
            }
        }

        // When swipe from left to right, user ends his turn
        override fun onFling(
            e1: MotionEvent,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            // if user haven't placed bet, user can't end
            if (editBet.visibility != ViewGroup.INVISIBLE){
                Toast.makeText(this@GameActivity, "Please Enter Bet", Toast.LENGTH_SHORT).show()
                return false
                // if game is over, user can't end
            } else if (isGameOver) {
                Toast.makeText(this@GameActivity, "Game Is Over", Toast.LENGTH_SHORT).show()
                return false
            } else {
                if (e2.x - e1.x > swipeDistance) {
                    computerTurn()
                    Log.e("final val", computerVal.toString())
                    return true
                }
                return false
            }
        }

        // When long pressing, user can double its bet amount
        override fun onLongPress(e: MotionEvent?) {
            super.onLongPress(e)
            if (editBet.visibility != ViewGroup.INVISIBLE){
                Toast.makeText(this@GameActivity, "Please Enter Bet", Toast.LENGTH_SHORT).show()
            } else if (isGameOver) {
                Toast.makeText(this@GameActivity, "Game Is Over", Toast.LENGTH_SHORT).show()
            } else {
                val dialogView = LayoutInflater.from(this@GameActivity).inflate(R.layout.dialog_double, null)
                val mBuilder = AlertDialog.Builder(this@GameActivity)
                    .setView(dialogView)
                    .setTitle("Do you want to double bet?")

                val mAlertDialog = mBuilder.show()

                mAlertDialog.confDouble.setOnClickListener{
                    betAmount += betAmount
                    mAlertDialog.dismiss()
                    Toast.makeText(this@GameActivity, "Now Bet Amount is $betAmount", Toast.LENGTH_SHORT).show()
                }
                mAlertDialog.cancelDouble.setOnClickListener {
                    mAlertDialog.dismiss()
                }
            }
        }
    }

    // generate card and return the card id
    private fun generateCard(): Int {
        val randomizer: CardRandomizer = CardRandomizer()
        val cardList: ArrayList<Int> = randomizer.getIDs(this) as ArrayList<Int>
        val rand: Random = Random()
        val r: Int = rand.nextInt(cardList.size)
        val id: Int = cardList.get(r)
        return id
    }

    // create images and put it into right place
    private fun createImage(linearLayout: LinearLayout, id: Int) {
        val newDeckView = generateBack()
        var layout = linearLayout
        // Form new Line to store the card when the number of cards in a line reaches 5
        if (linearLayout == userCard){
            userCardNums++
            if (userCardNums<=5){
                moveTo(newDeckView,userX, userY)
                userX+=cardWidth
            } else {
                layout = userCard2
                userX = (userCardNums-6)*cardWidth
                userY -= cardHeight
                moveTo(newDeckView,userX,userY)
            }
        } else {
            pcCardNums++
            if (pcCardNums<=5){
                moveTo(newDeckView, pcX, pcY)
                pcX+=cardWidth
            } else {
                layout = computerCard2
                pcX = (pcCardNums-6)*cardWidth
                pcY += cardHeight
                moveTo(newDeckView, pcX, pcY)
            }
        }
        val newCard = ImageView(this)
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        newCard.setImageResource(id)
        newCard.maxWidth = (transDP(84)).toInt()
        newCard.maxHeight = (transDP(84)).toInt()
        newCard.adjustViewBounds = true
        newCard.layoutParams = params


        // use handler to implement delay
        val runnable: Runnable = Runnable {
            layout.addView(newCard)
        }

        picHandle.postDelayed(runnable, 1000)

    }

    // generate card "back" for animation
    private fun generateBack() : View {
        val newDeckView = ImageView(this)
        val param = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        newDeckView.maxWidth = (transDP(84)).toInt()
        newDeckView.maxHeight = (transDP(84)).toInt()
        newDeckView.adjustViewBounds = true
        newDeckView.layoutParams = param
        val id = this.getResources().getIdentifier("back", "drawable",packageName)
        newDeckView.setImageResource(id)

        mainGame.addView(newDeckView)

        return newDeckView
    }

    // transform DP to SP
    private fun transDP(dp: Int): Double {
        return dp*(this.getResources().displayMetrics.density) + 0.5
    }

    private fun retrans(sp: Int) : Int {
        return ((sp-0.5)/(this.getResources().displayMetrics.density)).toInt()
    }
}