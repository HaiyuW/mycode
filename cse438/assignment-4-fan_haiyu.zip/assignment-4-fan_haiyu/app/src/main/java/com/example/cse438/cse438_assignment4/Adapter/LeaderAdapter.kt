package com.example.cse438.cse438_assignment4.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cse438.cse438_assignment4.Data.User
import com.example.cse438.cse438_assignment4.R

// adapter for leaderboard recycler view
class LeaderViewHolder(inflater: LayoutInflater, parent: ViewGroup):
        RecyclerView.ViewHolder(inflater.inflate(R.layout.item_leader, parent, false)) {

    public var seqNum: TextView
    public var userChip: TextView

    init {
        seqNum = itemView.findViewById(R.id.seqNum)
        userChip = itemView.findViewById(R.id.leaderBoards)
    }

    fun bind(user: User) {
        userChip.text = user.username + " with " + user.chips + " chips"
    }

}

class LeaderAdapter (private val list: ArrayList<User>) :
        RecyclerView.Adapter<LeaderViewHolder>() {
    private var userlist: ArrayList<User> = list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaderViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return LeaderViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: LeaderViewHolder, position: Int) {
        val user: User = userlist.get(position)
        holder.seqNum.text = (position+1).toString()+". "
        holder.bind(user)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}