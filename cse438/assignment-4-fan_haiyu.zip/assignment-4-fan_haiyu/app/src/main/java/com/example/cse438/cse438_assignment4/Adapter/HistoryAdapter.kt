package com.example.cse438.cse438_assignment4.Adapter

import com.example.cse438.cse438_assignment4.Data.History
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cse438.cse438_assignment4.Data.User
import com.example.cse438.cse438_assignment4.R

// adapter for history recycler view
class HistoryViewHolder(inflater: LayoutInflater, parent: ViewGroup):
    RecyclerView.ViewHolder(inflater.inflate(R.layout.item_leader, parent, false)) {

    public var seqNum: TextView
    public var userChip: TextView

    init {
        seqNum = itemView.findViewById(R.id.seqNum)
        userChip = itemView.findViewById(R.id.leaderBoards)
    }

    fun bind(history: History) {
        userChip.text = history.status + "        " + history.chipStatus +" chips"
    }

}

class HistoryAdapter (private val list: ArrayList<History>)
    :RecyclerView.Adapter<HistoryViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return HistoryViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val history: History = list[position]
        holder.seqNum.text = (position+1).toString()+". "
        holder.bind(history)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}