package com.example.cse438.cse438_assignment4.Fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.cse438.cse438_assignment4.Activity.GameActivity
import com.example.cse438.cse438_assignment4.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_register.*

// login fragment
class LoginFragment: Fragment() {
    private lateinit var auth: FirebaseAuth
    private lateinit var userDB: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        auth = FirebaseAuth.getInstance()

        userDB = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setTimestampsInSnapshotsEnabled(true)
            .build()
        userDB.firestoreSettings = settings

        // input the email and password, then login
        loginBtn.setOnClickListener{

            val email = emailLog.text.toString()
            val password = passwordLog.text.toString()

            if (email=="") {
                Toast.makeText(this.context,"Invalid Email", Toast.LENGTH_SHORT).show()
            } else if (password=="") {
                Toast.makeText(this.context,"Invalid Password", Toast.LENGTH_SHORT).show()
            } else {
                logIn(email,password)
            }
        }
    }

    // login function using firebase authentication
    private fun logIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email,password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("success", "login success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    Toast.makeText(this.context, "Authentication failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    // update UI to game
    private fun updateUI(user: FirebaseUser?) {

        var username = ""

        if (user!=null) {
            userDB.collection("accounts")
                .whereEqualTo("uid",user.uid)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        for (document in task.result!!) {
                            username = document.get("username").toString()
                        }
                        var bundle = Bundle()
                        bundle.putString("username", username)
                        bundle.putString("uid", user.uid)
                        val intent = Intent(this.context, GameActivity::class.java)
                        intent.putExtras(bundle)
                        startActivity(intent)
                        Log.e("user",username)
                    } else {
                        Log.e("d", "fail")
                    }
                }
        }
    }
}