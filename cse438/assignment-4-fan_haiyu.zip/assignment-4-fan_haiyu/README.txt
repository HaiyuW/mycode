Group Member:
Haiyu Wang, Fan Wu

* Is there anything that you did that you feel might be unclear? Explain it here.

In the creative portion, I want to show the history of each round of the user. It will show if the user win or lose or tie and how many chips are involved.

But when I add data into the firebase database and get the data from firebase, its sequence will not follow that when I insert the data.

I'm not sure how to deal with this problem.

Creative Portion
1. Long Press to double the bet amount

Feature: 
After users place the bet, they can long press the screen and then it will pop up a dialog to ask users if they want to double the bet amount. If "confirm" is pressed, the bet amount will double. If "cancel" is pressed, the dialog dismisses.

Reason:
As we know, in blackjack, players can change their bet at each round of the game. Users can choose if they will double the bet amount according to the card number of dealer's.

Implementation:
In the MyGestureListener, we override the function "onLongPress" and use dialog view to pop up the dialog. We also use a variable "betAmount" to store the bet amount in this round of the game.

2. History of the play
Feature:
Users can press the history button and switch into HistoryActivty. Then it will show the status(win/lose/tie) of each game and how many chips are involved.

Reason:
Users can check their history to see the list of the game status and chips got or lost. This feature provides an explicit document of the games

Implementation:
At the end of each game, we will insert the game status into the firebase database. In the history activity, we use recycler view to get the data from the firebase database.

