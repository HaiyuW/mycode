package com.example.cse438.cse438_assignment2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cse438.cse438_assignment2.Adapter.DataListAdapter
import com.example.cse438.cse438_assignment2.data.Data
import com.example.cse438.cse438_assignment2.data.Track
import com.example.cse438.cse438_assignment2.fragments.HomeFragment
import com.example.cse438.cse438_assignment2.fragments.PlaylistFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: DataViewModel
    var trackList: ArrayList<Track> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tabAdapter = ViewPagerAdapter(supportFragmentManager)
        tabAdapter.addFragment(HomeFragment(), "HOME")
        tabAdapter.addFragment(PlaylistFragment(),"PLAYLISTS")
        viewPager?.adapter = tabAdapter
        tabs.setupWithViewPager(viewPager)

    }
}
