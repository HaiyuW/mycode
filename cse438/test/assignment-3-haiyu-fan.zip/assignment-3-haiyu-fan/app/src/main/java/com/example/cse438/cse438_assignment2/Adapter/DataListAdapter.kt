package com.example.cse438.cse438_assignment2.Adapter

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.Fragment
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cse438.cse438_assignment2.R
import com.example.cse438.cse438_assignment2.data.Data
import com.example.cse438.cse438_assignment2.data.Track
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.track_item.view.*

class DataViewHolder(inflater: LayoutInflater, parent: ViewGroup):
        RecyclerView.ViewHolder(inflater.inflate(R.layout.track_item, parent, false)) {
    private val trackNameView: TextView
    private val trackPicView: ImageView

    init {
        trackNameView = itemView.findViewById(R.id.track_name)
        trackPicView = itemView.findViewById(R.id.track_pic)
    }

    fun bind(track: Track){
        trackNameView?.text = track.title
        Picasso.get().load(track.album.cover).into(trackPicView)
        trackPicView.setOnClickListener {

        }

    }
}

class DataListAdapter(private val list: ArrayList<Track>)
    : RecyclerView.Adapter<DataViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return DataViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        val track: Track = list[position]
        holder.bind(track)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}
