package com.example.cse438.cse438_assignment2.data

data class Data(
    val data: List<Track>,
    val total: Int,
    val next: String
)