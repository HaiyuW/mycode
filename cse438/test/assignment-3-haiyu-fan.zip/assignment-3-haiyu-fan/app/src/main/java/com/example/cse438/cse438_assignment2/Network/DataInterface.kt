package com.example.cse438.cse438_assignment2.Network

import com.example.cse438.cse438_assignment2.data.Data
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface DataInterface {
    @GET("chart/0/tracks")
    suspend fun getDateByChart(): Response<Data>

    @GET("search")
    suspend fun getDataBySearch(@Query("q") data: String) : Response<Data>
}